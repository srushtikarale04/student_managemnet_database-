#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

void delete_student(void)
{
    struct student *temp, *del;
    char choice, name[50];
    int roll, found = 0;
    int search_by_name = 0;

    if (head == NULL)
    {
        printf("No records available.\n");
        return;
    }

    printf("Delete by R/r (roll number) or N/n (name): ");
    scanf(" %c", &choice);

    if (choice == 'r' || choice == 'R')
    {
        printf("Enter roll number: ");
        scanf("%d", &roll);
    }
    else if (choice == 'n' || choice == 'N')
    {
        printf("Enter name: ");
        scanf(" %49[^\n]", name);

        temp = head;
        while (temp != NULL)
        {
            if (strcmp(temp->name, name) == 0)
            {
                printf("Roll: %d  Name: %s  Percentage: %.2f\n",
                       temp->rollno, temp->name, temp->percentage);
                found++;
            }
            temp = temp->next;
        }

        if (found == 0)
        {
            printf("Student name not found.\n");
            return;
        }

        printf("Enter the roll number of the record to delete: ");
        scanf("%d", &roll);
    }
    else
    {
        printf("Invalid choice.\n");
        return;
    }

    if (search_by_name)
    {
        temp = head;
        while (temp != NULL && temp->rollno != roll)
            temp = temp->next;

        if (temp == NULL || strcmp(temp->name, name) != 0)
        {
            printf("Selected roll number does not match that name.\\n");
            return;
        }
    }

    if (head->rollno == roll)
    {
        del = head;
        head = head->next;
        free(del);
        printf("Record deleted successfully.\n");
        return;
    }

    temp = head;
    while (temp->next != NULL && temp->next->rollno != roll)
        temp = temp->next;

    if (temp->next == NULL)
    {
        printf("Roll number not found.\n");
        return;
    }

    del = temp->next;
    temp->next = del->next;
    free(del);

    printf("Record deleted successfully.\n");
}
