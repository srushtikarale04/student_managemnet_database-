#include <stdio.h>
#include <string.h>
#include "student.h"

void modify_student(void)
{
    struct student *temp;
    char choice, name[50];
    int roll, found = 0;

    if (head == NULL)
    {
        printf("No records available.\n");
        return;
    }

    printf("Modify by R/r (roll), N/n (name), P/p (percentage): ");
    scanf(" %c", &choice);

    if (choice == 'r' || choice == 'R')
    {
        printf("Enter roll number: ");
        scanf("%d", &roll);

        temp = head;
        while (temp != NULL && temp->rollno != roll)
            temp = temp->next;
    }
    else if (choice == 'n' || choice == 'N')
    {
        printf("Enter name: ");
        scanf(" %49[^\n]", name);

        temp = head;
        while (temp != NULL)
        {
            if (strcmp(temp->name, name) == 0)
            {
                printf("Roll: %d  Name: %s  Percentage: %.2f\n",
                       temp->rollno, temp->name, temp->percentage);
                found++;
            }
            temp = temp->next;
        }

        if (found == 0)
        {
            printf("Student name not found.\n");
            return;
        }

        if (found > 1)
        {
            printf("Enter roll number of the record to modify: ");
            scanf("%d", &roll);
        }
        else
        {
            temp = head;
            while (temp != NULL && strcmp(temp->name, name) != 0)
                temp = temp->next;
            roll = temp->rollno;
        }

        temp = head;
        while (temp != NULL && temp->rollno != roll)
            temp = temp->next;

        if (temp == NULL || strcmp(temp->name, name) != 0)
        {
            printf("Selected roll number does not match that name.\n");
            return;
        }
    }
    else if (choice == 'p' || choice == 'P')
    {
        float percentage;

        printf("Enter percentage to search: ");
        scanf("%f", &percentage);

        temp = head;
        while (temp != NULL)
        {
            if (temp->percentage == percentage)
            {
                printf("Roll: %d  Name: %s  Percentage: %.2f\n",
                       temp->rollno, temp->name, temp->percentage);
                found++;
            }
            temp = temp->next;
        }

        if (found == 0)
        {
            printf("No record found with that percentage.\n");
            return;
        }

        if (found > 1)
        {
            printf("Enter roll number of the record to modify: ");
            scanf("%d", &roll);
        }
        else
        {
            temp = head;
            while (temp != NULL && temp->percentage != percentage)
                temp = temp->next;
            roll = temp->rollno;
        }

        temp = head;
        while (temp != NULL && temp->rollno != roll)
            temp = temp->next;

        if (temp == NULL || temp->percentage != percentage)
        {
            printf("Selected roll number does not match that percentage.\n");
            return;
        }
    }
    else
    {
        printf("Invalid choice.\n");
        return;
    }

    if (choice == 'r' || choice == 'R')
    {
        if (temp == NULL)
        {
            printf("Roll number not found.\n");
            return;
        }
    }

    printf("Enter new name: ");
    scanf(" %49[^\n]", temp->name);

    do
    {
        printf("Enter new percentage (0 to 100): ");
        if (scanf("%f", &temp->percentage) != 1)
        {
            printf("Invalid input.\n");
            return;
        }

        if (temp->percentage < 0 || temp->percentage > 100)
            printf("Percentage must be between 0 and 100.\n");

    } while (temp->percentage < 0 || temp->percentage > 100);

    printf("Record modified successfully.\n");
}
