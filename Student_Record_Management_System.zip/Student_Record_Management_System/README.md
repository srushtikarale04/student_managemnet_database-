# Student Record Management System

A menu-driven student record management project written in C using a **Singly Linked List (SLL)**.

## Features

- Add student records with the smallest available positive roll number
- Delete a record by roll number or name
- Display all student records
- Modify a record by roll number, name, or percentage
- Save and load records using `student.dat`
- Sort by name (A to Z) or percentage (high to low)
- Delete all records from memory
- Reverse the singly linked list
- Exit with or without saving

## Project files

| File | Purpose |
|---|---|
| `student.h` | Structure, global head declaration, and function prototypes |
| `stud_main.c` | Main menu and program flow |
| `stud_add.c` | Add a student |
| `stud_del.c` | Delete a student |
| `stud_show.c` | Display student records |
| `stud_mod.c` | Modify a student |
| `stud_save.c` | Save, load, delete all, sort, reverse, and exit |

## Requirements

- GCC compiler
- Terminal or command prompt

## Compile

Run this command from the project folder:

```bash
gcc stud_main.c stud_add.c stud_del.c stud_show.c stud_mod.c stud_save.c -o student
```

## Run

On Linux or macOS:

```bash
./student
```

On Windows (MinGW):

```bash
student.exe
```

The program reads from and writes to `student.dat` in the current working directory.

## Data file

`student.dat` is created when records are saved. It is intentionally not included in this repository because it may contain personal student information.

## Concepts used

- Structures
- Singly Linked List
- Pointers
- Dynamic memory allocation (`malloc` and `free`)
- Functions and modular programming
- File handling
- Searching, sorting, and reversing linked lists
