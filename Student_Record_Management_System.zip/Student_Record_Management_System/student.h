#ifndef STUDENT_H
#define STUDENT_H

struct student
{
    int rollno;
    char name[50];
    float percentage;
    struct student *next;
};

extern struct student *head;

void add_student(void);
void delete_student(void);
void show_student(void);
void modify_student(void);
void save_records(void);
void load_records(void);
void delete_all(void);
void sort_list(void);
void reverse_list(void);
void exit_program(void);

#endif
