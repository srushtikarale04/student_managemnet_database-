#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

void add_student(void)
{
    struct student *newnode, *temp;
    int roll, used;

    newnode = malloc(sizeof(struct student));
    if (newnode == NULL)
    {
        printf("Memory allocation failed.\n");
        return;
    }

    /* Find the smallest unused positive roll number. */
    roll = 1;
    while (1)
    {
        used = 0;
        temp = head;

        while (temp != NULL)
        {
            if (temp->rollno == roll)
            {
                used = 1;
                break;
            }
            temp = temp->next;
        }

        if (used == 0)
            break;

        roll++;
    }

    newnode->rollno = roll;

    printf("Enter student name: ");
    scanf(" %49[^\n]", newnode->name);

    do
    {
        printf("Enter percentage (0 to 100): ");
        if (scanf("%f", &newnode->percentage) != 1)
        {
            printf("Invalid input.\n");
            free(newnode);
            return;
        }

        if (newnode->percentage < 0 || newnode->percentage > 100)
            printf("Percentage must be between 0 and 100.\n");

    } while (newnode->percentage < 0 || newnode->percentage > 100);

    newnode->next = NULL;

    if (head == NULL)
    {
        head = newnode;
    }
    else
    {
        temp = head;
        while (temp->next != NULL)
            temp = temp->next;

        temp->next = newnode;
    }

    printf("Student added successfully. Roll number: %d\n", roll);
}
