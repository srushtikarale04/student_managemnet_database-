#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

void save_records(void)
{
    FILE *fp;
    struct student *temp;

    fp = fopen("student.dat", "w");
    if (fp == NULL)
    {
        printf("Unable to open student.dat for writing.\n");
        return;
    }

    temp = head;
    while (temp != NULL)
    {
        fprintf(fp, "%d\t%s\t%.2f\n",
                temp->rollno, temp->name, temp->percentage);
        temp = temp->next;
    }

    fclose(fp);
    printf("Records saved successfully.\n");
}

void load_records(void)
{
    FILE *fp;
    struct student *newnode, *temp;
    int roll;
    char name[50];
    float percentage;

    fp = fopen("student.dat", "r");
    if (fp == NULL)
        return;

    while (fscanf(fp, "%d\t%49[^\t]\t%f", &roll, name, &percentage) == 3)
    {
        newnode = malloc(sizeof(struct student));
        if (newnode == NULL)
        {
            printf("Memory allocation failed while loading records.\n");
            break;
        }

        newnode->rollno = roll;
        strcpy(newnode->name, name);
        newnode->percentage = percentage;
        newnode->next = NULL;

        if (head == NULL)
        {
            head = newnode;
        }
        else
        {
            temp = head;
            while (temp->next != NULL)
                temp = temp->next;
            temp->next = newnode;
        }
    }

    fclose(fp);
}

void delete_all(void)
{
    struct student *temp;

    while (head != NULL)
    {
        temp = head;
        head = head->next;
        free(temp);
    }

    head = NULL;
    printf("All records deleted from memory.\n");
}

void sort_list(void)
{
    struct student *temp, *temp2;
    char choice;
    int roll;
    float percentage;
    char name[50];

    if (head == NULL || head->next == NULL)
    {
        printf("Not enough records to sort.\n");
        return;
    }

    printf("N/n : Sort by name (A to Z)\n");
    printf("P/p : Sort by percentage (high to low)\n");
    printf("Enter choice: ");
    scanf(" %c", &choice);

    if (choice != 'n' && choice != 'N' &&
        choice != 'p' && choice != 'P')
    {
        printf("Invalid choice.\n");
        return;
    }

    temp = head;
    while (temp->next != NULL)
    {
        temp2 = temp->next;

        while (temp2 != NULL)
        {
            if (((choice == 'n' || choice == 'N') &&
                 strcmp(temp->name, temp2->name) > 0) ||
                ((choice == 'p' || choice == 'P') &&
                 temp->percentage < temp2->percentage))
            {
                roll = temp->rollno;
                temp->rollno = temp2->rollno;
                temp2->rollno = roll;

                strcpy(name, temp->name);
                strcpy(temp->name, temp2->name);
                strcpy(temp2->name, name);

                percentage = temp->percentage;
                temp->percentage = temp2->percentage;
                temp2->percentage = percentage;
            }

            temp2 = temp2->next;
        }

        temp = temp->next;
    }

    printf("Records sorted successfully.\n");
}

void reverse_list(void)
{
    struct student *current, *nextnode, *temp;

    if (head == NULL || head->next == NULL)
    {
        printf("Not enough records to reverse.\n");
        return;
    }

    temp = NULL;
    current = head;

    while (current != NULL)
    {
        nextnode = current->next;
        current->next = temp;
        temp = current;
        current = nextnode;
    }

    head = temp;
    printf("List reversed successfully.\n");
}

void exit_program(void)
{
    char choice;

    while (1)
    {
        printf("\nS/s : Save and exit\n");
        printf("E/e : Exit without saving\n");
        printf("Enter choice: ");
        scanf(" %c", &choice);

        if (choice == 's' || choice == 'S')
        {
            save_records();
            delete_all();
            return;
        }
        else if (choice == 'e' || choice == 'E')
        {
            delete_all();
            return;
        }
        else
        {
            printf("Invalid choice.\n");
        }
    }
}
