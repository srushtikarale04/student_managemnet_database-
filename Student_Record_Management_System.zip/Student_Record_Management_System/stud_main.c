#include <stdio.h>
#include "student.h"

struct student *head = NULL;

int main(void)
{
    char choice;

    load_records();

    while (1)
    {
        printf("\n========== STUDENT RECORD MANAGEMENT ==========\n");
        printf("A/a : Add student\n");
        printf("D/d : Delete student\n");
        printf("S/s : Show students\n");
        printf("M/m : Modify student\n");
        printf("V/v : Save records\n");
        printf("T/t : Sort records\n");
        printf("L/l : Delete all records\n");
        printf("R/r : Reverse records\n");
        printf("E/e : Exit\n");
        printf("Enter your choice: ");

        if (scanf(" %c", &choice) != 1)
            break;

        switch (choice)
        {
            case 'a':
            case 'A':
                add_student();
                break;

            case 'd':
            case 'D':
                delete_student();
                break;

            case 's':
            case 'S':
                show_student();
                break;

            case 'm':
            case 'M':
                modify_student();
                break;

            case 'v':
            case 'V':
                save_records();
                break;

            case 't':
            case 'T':
                sort_list();
                break;

            case 'l':
            case 'L':
                delete_all();
                break;

            case 'r':
            case 'R':
                reverse_list();
                break;

            case 'e':
            case 'E':
                exit_program();
                return 0;

            default:
                printf("Invalid choice. Try again.\n");
        }
    }

    delete_all();
    return 0;
}
